package com.practice.caleb.newcalendarapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class CalendarActivity extends AppCompatActivity {

    private static final String TAG = "CalendarActivity";

    private CalendarView mCalendarView;
    private Button btnAdd;
    private Button btnSettings;
    Boolean fromEventCreate;
    Date date;
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    ArrayAdapter<String> adapter;
    ArrayList<String> eventStringArrayList = new ArrayList<String>();
    ArrayList<Event> eventArrayList =new ArrayList<Event>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_layout);
        mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnSettings = (Button) findViewById(R.id.btnSettings);

        Event event1 = new Event("Lunch", "13:00");
        Event event2 = new Event("Brunch", "10:00");
        Event event3 = new Event("Runch", "11:00");
        Event event4 = new Event("Desert", "21:00");
        Event event5 = new Event("Dinner", "19:00");
        Event event6 = new Event("Breaky", "08:00");
        try {
            Intent incoming = getIntent();
            fromEventCreate = incoming.getExtras().getBoolean("create");
            if(fromEventCreate != null && fromEventCreate){
                String name = incoming.getStringExtra("name");
                String time = incoming.getStringExtra("time");
                String strDate = incoming.getStringExtra("strDate");
                Event event = new Event(name, time, strDate);
                eventArrayList.add(event);
            }
            fromEventCreate = false;
        }catch(RuntimeException e){
        }

        eventArrayList.add(event1);
        eventArrayList.add(event2);
        eventArrayList.add(event3);
        eventArrayList.add(event4);
        eventArrayList.add(event5);
        eventArrayList.add(event6);

        ListView listView = (ListView) findViewById(R.id.eventList);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, eventStringArrayList);
        listView.setAdapter(adapter);

        try {
            date = sdf.parse(sdf.format(new Date()));
        }catch (ParseException e){
        }
        checkEventsOnDay();

        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String dateGet = dayOfMonth + "/" + (month + 1) + "/" + year;
                //Log.d(TAG, "onSelectedDayChange: dd/mm/yyyy: " + dateGet);

                try {
                    date = (sdf.parse(dateGet));
                    //checkEventsOnDay(dateGet);
                } catch (ParseException e) {
                }
                checkEventsOnDay();
                /*
                Intent intent = new Intent(CalendarActivity.this, MainActivity.class);
                intent.putExtra("date", date);
                startActivity(intent);*/
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addBtn();
            }
        });
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                settingsBtn();
            }
        });
    }

    public void checkEventsOnDay(){
        /*date = sdf.parse(dateGet);
        Date dateSept = sdf.parse("05/09/2018");
        setDate(dateGet);*/

        Collections.sort(eventArrayList);

        eventStringArrayList.clear();

        for(Event event : eventArrayList){
            if(event.getDate().equals(date)){
                eventStringArrayList.add(event.toString());
            }else {
                eventStringArrayList.remove(event.toString());
            }
        }
        adapter.notifyDataSetChanged();
    }

    public void addBtn() {
        Intent addBtnIntent = new Intent(CalendarActivity.this, CreateEventActivity.class);
        String strDate = sdf.format(date);
        addBtnIntent.putExtra("date", strDate);
        startActivity(addBtnIntent);
    }
    public void settingsBtn(){
        Intent settingsBtnIntent = new Intent(CalendarActivity.this, SettingsActivity.class);
        startActivity(settingsBtnIntent);
    }
/*
    public void setDate(String newDate) {
        try {
            date = sdf.parse(newDate);
        } catch (ParseException e) {

        }
    }*/
}
