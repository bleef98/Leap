package com.practice.caleb.newcalendarapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.TestLooperManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Date;

public class CreateEventActivity  extends AppCompatActivity {
    EditText name;
    EditText time;
    String strDate;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_event);


        Intent incoming = getIntent();
        strDate = incoming.getStringExtra("date");

        Button btnCreate = (Button) findViewById(R.id.btnCreate);
        Button btnCancel = (Button) findViewById(R.id.btnCancel);

        name = (EditText) findViewById(R.id.editTextName);
        time = (EditText) findViewById(R.id.editTextTime);


        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CreateEventActivity.this, CalendarActivity.class);
                intent.putExtra("create", true);
                intent.putExtra("name", name.getText().toString());
                intent.putExtra("time", time.getText().toString());
                intent.putExtra("strDate", strDate);
                startActivity(intent);
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CreateEventActivity.this, CalendarActivity.class);
                startActivity(intent);
            }
        });
    }
}
